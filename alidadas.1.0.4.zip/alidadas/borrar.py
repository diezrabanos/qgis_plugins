# -*- coding: utf-8 -*-


def generapunto(x,y):
            #creo una capa de puntos temporal con los resultados
            # create layer
            vl = QgsVectorLayer("Point", "Pto_Cruce", "memory")
            pr = vl.dataProvider()
            #print ("ok creada la capa")
            vl.startEditing()
            # add fields
            pr.addAttributes([
                            QgsField("x",  QVariant.Int),
                            QgsField("y", QVariant.Double)])
            vl.updateFields() 
            # tell the vector layer to fetch changes from the provider
            #print ("ok creados los campos")
            # add a feature
            fet = QgsFeature()
            fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x,y)))

            fet.setAttributes([ x, y])
            pr.addFeatures([fet])
            #print ("ok, anadido el elemento con error "+str(error))
            #cambio la simbologia
            symbol = QgsMarkerSymbol.createSimple({'name': 'circle', 'color': 'red','size': '5',})
            vl.renderer().setSymbol(symbol)

            # update layer's extent when new features have been added
            # because change of extent in provider is not propagated to the layer
            #vl.updateExtents()
            vl.commitChanges()
            #vl.updateExtents()
            # show the point
            if x!=0 and y!=0:
                QgsProject.instance().addMapLayers([vl])
                canvas = iface.mapCanvas()
            #canvas.setExtent(vl.extent())
            #vl.updateFieldMap()


generapunto(500000,4600000)

            
