To execute OruxMapsDesktop:

-->windows double click in OruxMapsDesktop.bat
-->linux double click in OruxMapsDesktop.sh

IMPORTANT: keep directory structure if you want that OruxMapsDesktop works fine!



Using Sqlite maps:

You need to copy in /lib/ folder sqlite native library.

You can find precompiled versions for your system here:

http://sourceforge.net/projects/trekbuddyatlasc/files/SQLite%20library
