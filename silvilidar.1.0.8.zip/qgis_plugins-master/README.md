# qgis_plugins
Plugins desarrollados para QGIS 3, relacionados con medioambiente
Para instalarlos es necesario incorporar un nuevo repositorio de complementos. Para ello desde QGIS 3.0 o superior ir al menú Complementos, después a Administrar e instalar complementos... y despues a Configuración. Ahí Añadir... y poner de nombre, por ejemplo SIGMENA y en url pegar lo siguiente:

https://raw.githubusercontent.com/diezrabanos/qgis_plugins/master/servidor_descargas_sigmena.xml

Ahora apareceran dentro de Todos los complementos, ademas de los del repositorio oficial de complementos de QGIS lo que vaya creando aquí.
