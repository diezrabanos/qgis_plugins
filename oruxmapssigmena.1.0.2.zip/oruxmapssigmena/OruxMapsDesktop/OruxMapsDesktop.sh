java -Xmx1024m -jar OruxMapsDesktop.jar
